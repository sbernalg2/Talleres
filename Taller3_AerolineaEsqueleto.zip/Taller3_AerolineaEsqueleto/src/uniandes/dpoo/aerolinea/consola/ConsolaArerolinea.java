package uniandes.dpoo.aerolinea.consola;

import java.io.IOException;

import org.json.JSONException;

import uniandes.dpoo.aerolinea.exceptions.AeropuertoDuplicadoException;
import uniandes.dpoo.aerolinea.exceptions.InformacionInconsistenteException;
import uniandes.dpoo.aerolinea.modelo.Aerolinea;
import uniandes.dpoo.aerolinea.persistencia.CentralPersistencia;
import uniandes.dpoo.aerolinea.persistencia.TipoInvalidoException;

public class ConsolaArerolinea extends ConsolaBasica
{
    private Aerolinea unaAerolinea;

    /**
     * Es un método que corre la aplicación y realmente no hace nada interesante: sólo muestra cómo se podría utilizar la clase Aerolínea para hacer pruebas.
     * @throws AeropuertoDuplicadoException 
     * @throws JSONException 
     */
    public void correrAplicacion( ) throws JSONException, AeropuertoDuplicadoException
    {
        try
        {
            unaAerolinea = new Aerolinea( );
            // String archivo = this.pedirCadenaAlUsuario( "Digite el nombre del archivo json con la información de una aerolinea" );
            String archivo = "Aerolinea.json"; 
            unaAerolinea.cargarAerolinea( "./datos/" + archivo, CentralPersistencia.JSON );
            archivo = "tiquetes.json"; 
            unaAerolinea.cargarTiquetes( "./datos/" + archivo, CentralPersistencia.JSON );
        }
        catch( TipoInvalidoException e )
        {
            e.printStackTrace( );
        }
        catch( IOException e )
        {
            e.printStackTrace();
        }
        catch( InformacionInconsistenteException e )
        {
            e.printStackTrace();
        }
    }

    private void mostrarMenuPrincipal( ) throws Exception
    {
    	String[] Opciones = new String[6];
		Opciones[0] = "Programar Vuelo";
		Opciones[1] = "Vender Tiquetes";
		Opciones[2] = "Registrar vuelo realizado";
		Opciones[3] = "Consultar saldo pendiente de cliente";
		Opciones[4] = "Salvar aerolinea";
		Opciones[5] = "Cargar aerolinea";

        int opcion_seleccionada = mostrarMenu( "Menú principal", Opciones );
        if( opcion_seleccionada == 1 )
        {
            programarVuelo();
        }
        if( opcion_seleccionada == 2 )
        {
            venderTiquetes();
        }
        if( opcion_seleccionada == 3 )
        {
            registrarVueloRealizado();
        }
        
        if( opcion_seleccionada == 4 )
        {
            consultarSaldoPendiente();
        }
        if( opcion_seleccionada == 5 )
        {
            salvarAerolinea();
        }
        if( opcion_seleccionada == 6 )
        {
            cargarAerolinea();
        }


        mostrarMenuPrincipal( );
    }
    
    public void programarVuelo() throws Exception
    {
        try
        {
        	System.out.println("Los nombre de los aviones son sensibles a las mayusculas.");
            String fecha = pedirCadenaAlUsuario("Fecha del vuelo a programar");
            String codigoRuta = pedirCadenaAlUsuario("Codigo de ruta del vuelo a programar");
            String nombreAvion = pedirCadenaAlUsuario("Nombre del avion del vuelo a programar");
            
            unaAerolinea.programarVuelo(fecha, codigoRuta, nombreAvion);
            System.out.println("El vuelo fue añadido");
        }
        catch( InformacionInconsistenteException e )
        {
            e.printStackTrace();
        }
    }
    
    public void venderTiquetes() throws Exception
    {
        try
        {
        	String identificadorCliente = pedirCadenaAlUsuario("Ingrese el identificador");
            String fecha = pedirCadenaAlUsuario("Fecha del vuelo");
            String codigoRuta = pedirCadenaAlUsuario("Codigo de ruta del vuelo");
            Integer cantidad = Integer.parseInt(pedirCadenaAlUsuario("Cantidad de tiquetes a vender"));
            
            unaAerolinea.venderTiquetes(identificadorCliente, fecha, codigoRuta, cantidad);
        }
        catch( InformacionInconsistenteException e )
        {
            e.printStackTrace();
        }
    }
    
    public void salvarAerolinea() throws Exception
    {
        try
        {
            String archivo = "Aerolinea.json"; 
            unaAerolinea.salvarAerolinea( "./datos/" + archivo, CentralPersistencia.JSON );
        }
        catch( TipoInvalidoException e )
        {
            e.printStackTrace( );
        }
        catch( IOException e )
        {
            e.printStackTrace();
        }
    }
    
    public void cargarAerolinea() throws Exception
    {
        try
        {
            String archivo = "Aerolinea.json"; 
            unaAerolinea.cargarAerolinea( "./datos/" + archivo, CentralPersistencia.JSON );
        }
        catch( TipoInvalidoException e )
        {
            e.printStackTrace( );
        }
        catch( IOException e )
        {
            e.printStackTrace();
        }
    }
    
    
    public void registrarVueloRealizado() throws Exception
    {
        String fecha = pedirCadenaAlUsuario("Fecha del vuelo realizado a registrar");
		String codigoRuta = pedirCadenaAlUsuario("Codigo de ruta del vuelo realizado a registrar");
		
		unaAerolinea.registrarVueloRealizado(fecha, codigoRuta);
    }
    
    public void consultarSaldoPendiente() throws Exception
    {
    	System.out.println("Los identificadores de los clientes son sensibles a las mayusculas.");
    	String identificadorCliente = pedirCadenaAlUsuario("Identificador del cliente");
		String output = unaAerolinea.consultarSaldoPendienteCliente(identificadorCliente);
		System.out.println(output);
    }
    


    public static void main( String[] args ) throws Exception
    {
    	ConsolaArerolinea consolaAerolinea = new ConsolaArerolinea( );
    	consolaAerolinea.correrAplicacion( );
    	consolaAerolinea.mostrarMenuPrincipal();
        
    }
}
