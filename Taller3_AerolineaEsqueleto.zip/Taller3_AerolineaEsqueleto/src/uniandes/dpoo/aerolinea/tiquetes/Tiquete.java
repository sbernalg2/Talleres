package uniandes.dpoo.aerolinea.tiquetes;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public class Tiquete {
	private String codigo;
	private boolean usado;
	private Vuelo vuelo;
	private Cliente cliente;
	private Integer tarifa;

	
	public Tiquete(String codigo, Vuelo vuelo, Cliente clienteComprador, int tarifa) {
		this.cliente = clienteComprador;
		this.tarifa = tarifa;
		this.codigo = codigo;
		this.vuelo = vuelo;
	}
	
	public void marcarComoUsado() {
	}
	
	public Cliente getCliente() {
		return cliente;
	}
	
	public boolean esUsado() {
		return usado;
	}
	
	public String getCodigo() {
		return codigo;
	}
	public Integer getTarifa() {
		return tarifa;
	}
	public Vuelo getVuelo() {
		return vuelo;
	}
}
