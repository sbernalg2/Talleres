package uniandes.dpoo.aerolinea.persistencia;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import uniandes.dpoo.aerolinea.exceptions.AeropuertoDuplicadoException;
import uniandes.dpoo.aerolinea.modelo.Aerolinea;
import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Avion;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public class PersistenciaAerolineaJson implements IPersistenciaAerolinea {
	
	public void cargarAerolinea(String archivo, Aerolinea aerolinea) throws IOException, JSONException, AeropuertoDuplicadoException {
	    String contenidoEnElArchivo = new String(Files.readAllBytes(new File(archivo).toPath()));
	    JSONObject jsonArchivo = new JSONObject(contenidoEnElArchivo);
	    
	    Map<String, Aeropuerto> aeropuertos = new HashMap<>();
	    JSONArray jsonAeropuertos = jsonArchivo.getJSONArray("aeropuertos");
	    for (int i = 0; i < jsonAeropuertos.length(); i++) {
	        JSONObject jsonAeropuerto = jsonAeropuertos.getJSONObject(i);
	        Aeropuerto aeropuerto = new Aeropuerto(
	        		jsonAeropuerto.getString("nombre"),
	        		jsonAeropuerto.getString("codigo"),
	        		jsonAeropuerto.getString("ciudad"),
	        		jsonAeropuerto.getDouble("latitud"),
	        		jsonAeropuerto.getDouble("longitud"));
	        aeropuertos.put(jsonAeropuerto.getString("nombre"), aeropuerto);
	    }

	    Map<String, Avion> aviones = new HashMap<>();
	    JSONArray jsonAviones = jsonArchivo.getJSONArray("aviones");
	    for (int i = 0; i < jsonAviones.length(); i++) {
	        JSONObject jAvion = jsonAviones.getJSONObject(i);
	        Avion avion = new Avion(
	                jAvion.getString("nombre"),
	                jAvion.getInt("capacidad"));
	        aviones.put(jAvion.getString("nombre"), avion);
	        aerolinea.agregarAvion(avion);
	    }

	    JSONArray jsonRutas = jsonArchivo.getJSONArray("rutas");
	    for (int i = 0; i < jsonRutas.length(); i++) {
	        JSONObject jsonRuta = jsonRutas.getJSONObject(i);
	        Ruta ruta = new Ruta(
	        		aeropuertos.get(jsonRuta.getString("origen")),
	        		aeropuertos.get(jsonRuta.getString("destino")),
	        		jsonRuta.getString("horaSalida"),
	        		jsonRuta.getString("horaLlegada"),
	        		jsonRuta.getString("codigoRuta"));
	        aerolinea.agregarRuta(ruta);
	        
	    }

	    JSONArray jsonVuelos = jsonArchivo.getJSONArray("vuelos");
	    for (int i = 0; i < jsonVuelos.length(); i++) {
	        JSONObject jsonVuelo = jsonVuelos.getJSONObject(i);
	        Vuelo vuelo = new Vuelo(
	                aerolinea.getRuta(jsonVuelo.getString("ruta")),
	                jsonVuelo.getString("fecha"),
	                aviones.get(jsonVuelo.getString("avion")));
	        aerolinea.agregarVuelo(vuelo);

	        JSONArray jsonTiquetes = jsonVuelo.getJSONArray("tiquetes");
	        for (int j = 0; j < jsonTiquetes.length(); j++) {
	            JSONObject jsonTiquete = jsonTiquetes.getJSONObject(j);
	            Tiquete tiquete = new Tiquete(
	            		jsonTiquete.getString("codigoTiquete"), vuelo, aerolinea.getCliente(jsonTiquete.getString("cliente")),
	                    jsonTiquete.getInt("tarifa"));
	            if (jsonTiquete.getBoolean("usado"))
	            	tiquete.marcarComoUsado();
	        }
	    }
		
	}
	public void salvarAerolinea(String archivo, Aerolinea aerolinea) throws IOException {
		
			JSONObject jobject = new JSONObject( );
			JSONArray jsonVuelos = new JSONArray();
	        for (Vuelo vuelo : aerolinea.getVuelos()) {
	            JSONObject jsonVuelo = new JSONObject();
	            jsonVuelo.put("fecha", vuelo.getFecha());
	            jsonVuelo.put("ruta", vuelo.getRuta().getCodigoRuta()); // Assuming Ruta has a getCodigoRuta method
	            jsonVuelo.put("avion", vuelo.getAvion().getNombre()); // Assuming Avion has a getNombre method

	            JSONArray jsonTiquetes = new JSONArray();
	            for (Tiquete tiquete : vuelo.getTiquetes()) {
	                JSONObject jsonTiquete = new JSONObject();
	                jsonTiquete.put("codigoTiquete", tiquete.getCodigo());
	                jsonTiquete.put("tarifa", tiquete.getTarifa());
	                jsonTiquete.put("usado", tiquete.esUsado()); // Assuming Tiquete has esUsado method
	                jsonTiquete.put("cliente", tiquete.getCliente().getIdentificador()); // Assuming Cliente has getIdentificador method
	                jsonTiquetes.put(jsonTiquete);
	            }
	            jsonVuelo.put("tiquetes", jsonTiquetes);

	            jsonVuelos.put(jsonVuelo);
	        }

	        jobject.put("vuelos", jsonVuelos);

	        JSONArray jsonRutas = new JSONArray();
	        Set<Aeropuerto> uniqueAeropuertos = new HashSet<>();
	        for (Ruta ruta : aerolinea.getRutas()) {
	            JSONObject jsonRuta = new JSONObject();
	            jsonRuta.put("codigoRuta", ruta.getCodigoRuta());
	            jsonRuta.put("origen", ruta.getOrigen().getNombre());
	            jsonRuta.put("destino", ruta.getDestino().getNombre());
	            jsonRuta.put("horaSalida", ruta.getHoraSalida());
	            jsonRuta.put("horaLlegada", ruta.getHoraLlegada());
	            jsonRutas.put(jsonRuta);
	            uniqueAeropuertos.add(ruta.getOrigen());
	            uniqueAeropuertos.add(ruta.getDestino());
	        }
	        jobject.put("rutas", jsonRutas);

	        JSONArray jsonAviones = new JSONArray();
	        for (Avion avion : aerolinea.getAviones()) {
	            JSONObject jsonAvion = new JSONObject();
	            jsonAvion.put("nombre", avion.getNombre());
	            jsonAvion.put("capacidad", avion.getCapacidad());
	            jsonAviones.put(jsonAvion);
	        }
	        jobject.put("aviones", jsonAviones);
	        
	        JSONArray jsonAeropuertos = new JSONArray();
	        for (Aeropuerto aeropuerto : uniqueAeropuertos) {
	            JSONObject jsonAeropuerto = new JSONObject();
	            jsonAeropuerto.put("nombre", aeropuerto.getNombre());
	            jsonAeropuerto.put("codigo", aeropuerto.getCodigo());
	            jsonAeropuerto.put("ciudad", aeropuerto.getNombreCiudad());
	            jsonAeropuerto.put("latitud", aeropuerto.getLatitud());
	            jsonAeropuerto.put("longitud", aeropuerto.getLongitud());
	            jsonAeropuertos.put(jsonAeropuerto);
	        }
	        jobject.put("aeropuertos", jsonAeropuertos);

	        
	        try(PrintWriter printWriter = new PrintWriter(archivo)) {
	        	printWriter.write(jobject.toString(4));
	        }
	}
}
