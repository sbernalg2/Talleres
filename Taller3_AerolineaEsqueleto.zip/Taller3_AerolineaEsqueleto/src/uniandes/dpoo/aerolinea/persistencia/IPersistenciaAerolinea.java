package uniandes.dpoo.aerolinea.persistencia;

import java.io.IOException;

import org.json.JSONException;

import uniandes.dpoo.aerolinea.exceptions.AeropuertoDuplicadoException;
import uniandes.dpoo.aerolinea.modelo.Aerolinea;

public interface IPersistenciaAerolinea {
    void cargarAerolinea(String archivo, Aerolinea aerolinea) throws IOException, JSONException, AeropuertoDuplicadoException;
    void salvarAerolinea(String archivo, Aerolinea aerolinea)throws IOException;
}
