package uniandes.dpoo.aerolinea.modelo;

public class Avion {
	private Integer capacidad;
	private String nombre;

	
    public Avion(String nombre, int capacidad) {
        this.capacidad = capacidad;
        this.nombre = nombre;
    }
    
	public Integer getCapacidad() {
		return capacidad;
	}
	public String getNombre() {
		return nombre;
	}
}
