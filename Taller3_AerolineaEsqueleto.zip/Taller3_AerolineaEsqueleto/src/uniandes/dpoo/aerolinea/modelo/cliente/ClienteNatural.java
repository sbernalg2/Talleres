package uniandes.dpoo.aerolinea.modelo.cliente;

public class ClienteNatural extends Cliente {
	private String nombre;
	public static final String NATURAL = "Natural";
	
    public ClienteNatural(String nombre) {
        this.nombre = nombre;
    }
    
    public String getIdentificador() {
    	return this.nombre;
    }

    public String getTipoCliente() {
    	return NATURAL;
    }
}
