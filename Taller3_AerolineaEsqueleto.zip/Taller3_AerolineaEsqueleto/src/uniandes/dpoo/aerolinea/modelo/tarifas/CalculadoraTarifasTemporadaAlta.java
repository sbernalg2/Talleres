package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public class CalculadoraTarifasTemporadaAlta extends CalculadoraTarifas {
	protected static final int COSTO_POR_KM = 1000;
    
    public Integer calcularCostoBase(Vuelo vuelo, Cliente cliente) {
    	Aeropuerto origen = vuelo.getRuta().getOrigen();
    	Aeropuerto destino = vuelo.getRuta().getDestino();
    	Integer distancia = Aeropuerto.calcularDistancia(origen, destino);
    	
        return distancia * COSTO_POR_KM; 
    }
    public Double calcularPorcentajeDescuento(Cliente cliente) {
        return 0.0;
    }
}
