package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.cliente.ClienteCorporativo;

public class CalculadoraTarifasTemporadaBaja extends CalculadoraTarifas {
    protected static final int COSTO_POR_KM_NATURAL = 600;
    protected static final int COSTO_POR_KM_CORPORATIVO = 900;
    protected static final double DESCUENTO_PEQ = 0.02;
    protected static final double DESCUENTO_MEDIANAS = 0.1;
    protected static final double DESCUENTO_GRANDES = 0.2;

    
    public Integer calcularCostoBase(Vuelo vuelo, Cliente cliente) {
    	Aeropuerto origen = vuelo.getRuta().getOrigen();
    	Aeropuerto destino = vuelo.getRuta().getDestino();
        Integer distanciaRecorrida = Aeropuerto.calcularDistancia(origen, destino);

        if (cliente.getTipoCliente().equals("Natural")) {
            return distanciaRecorrida * COSTO_POR_KM_NATURAL;
        } else if (cliente.getTipoCliente().equals("Corporativo")) {
            return distanciaRecorrida * COSTO_POR_KM_CORPORATIVO;
            }
        
        return null;
    }
    public Double calcularPorcentajeDescuento(Cliente cliente) {
    	
        if (cliente.getTipoCliente().equals("Corporativo")) {
        	ClienteCorporativo clienteCorp = (ClienteCorporativo) cliente;
        	if(clienteCorp.getTamanoEmpresa().equals(1)) {
        		return DESCUENTO_GRANDES;
        	}
        	if(clienteCorp.getTamanoEmpresa().equals(2)) {
        		return DESCUENTO_MEDIANAS;
        	}
        	if(clienteCorp.getTamanoEmpresa().equals(3)) {
        		return DESCUENTO_PEQ;
        	}     
        }
		return 0.0;
    }
}
