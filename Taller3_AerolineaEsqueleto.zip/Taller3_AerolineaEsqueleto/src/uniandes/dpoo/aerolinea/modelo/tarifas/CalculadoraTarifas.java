package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public abstract class CalculadoraTarifas {
	public static final double IMPUESTO = 0.28;
	
	public int calcularTarifa(Vuelo vuelo, Cliente cliente) {
		Integer costoBase = calcularCostoBase(vuelo, cliente);
		Integer impuestos = calcularValorImpuestos(costoBase);
		Double porcentajeDeDescuento = calcularPorcentajeDescuento(cliente);
		Double valorDelDescuento = porcentajeDeDescuento * costoBase;


		return (int) (costoBase + impuestos - valorDelDescuento);
	}
	
	protected abstract Integer calcularCostoBase(Vuelo vuelo, Cliente cliente);
	
	protected abstract Double calcularPorcentajeDescuento(Cliente cliente);
	
	protected Integer calcularDistanciaVuelo(Ruta ruta) {
    	Aeropuerto origen = ruta.getOrigen();
    	Aeropuerto destino = ruta.getDestino();
    	Integer distancia = Aeropuerto.calcularDistancia(origen, destino);
		return distancia;
	}
	
	protected int calcularValorImpuestos(int costoBase) {
		return (int) (costoBase * IMPUESTO);
	}
}
