package uniandes.dpoo.aerolinea.modelo;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import uniandes.dpoo.aerolinea.exceptions.InformacionInconsistenteException;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.tarifas.CalculadoraTarifas;
import uniandes.dpoo.aerolinea.tiquetes.GeneradorTiquetes;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public class Vuelo {
	
    private Ruta ruta;
    private String fecha;
    private Avion avion;
    private Map<String, Tiquete> tiquetes;

	public Ruta getRuta() {
		return ruta;
	}
	public String getFecha() {
		return fecha;
	}
	public Avion getAvion() {
		return avion;
	}
	
	public Collection<Tiquete> getTiquetes() {
		return tiquetes.values();
	}

    public int venderTiquetes(Cliente cliente, CalculadoraTarifas calculadora, int cantidad) throws InformacionInconsistenteException {
        int asientosDisponibles = avion.getCapacidad() - tiquetes.size();
        if (cantidad > asientosDisponibles) {
            throw new InformacionInconsistenteException("No estan disponibles la cantidad de asientos que se requieren.");
        }

        int totalCost = 0;
        for (int i = 0; i < cantidad; i++) {
            int tarifa = calculadora.calcularTarifa(this, cliente);
            Tiquete tiquete = GeneradorTiquetes.generarTiquete(this, cliente, tarifa);
            cliente.agregarTiquete(tiquete);
            tiquetes.put(tiquete.getCodigo(), tiquete);
            totalCost += tarifa;
        }

        return totalCost;
    }
    
    public boolean equals(Object obj) {
    	return false;
    }

    public Vuelo(Ruta ruta, String fecha, Avion avion) {
        this.ruta = ruta;
        this.fecha = fecha;
        this.avion = avion;
        this.tiquetes = new HashMap<>();
    }
}
